"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CreateListingPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    title: '',
    description: '',
    price: '',
    bedrooms: '',
    bathrooms: '',
    address: '',
    city: '',
    state: '',
    country: 'USA',
    lat: '',
    lng: '',
    startDate: '',
    endDate: ''
  });
  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }
  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/listings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          price: Number(form.price),
          bedrooms: Number(form.bedrooms),
          bathrooms: Number(form.bathrooms),
          lat: Number(form.lat),
          lng: Number(form.lng),
          startDate: form.startDate,
          endDate: form.endDate || null,
          listerId: 'demo-user-id' // TODO: get from session
        })
      });
      if (!res.ok) {
        const json = await res.json();
        throw new Error(json.error || 'Failed to create listing');
      }
      const json = await res.json();
      router.push(`/listing/${json.data.slug}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }
  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Create a new listing</h1>
      {error && <p className="text-red-600 mb-4">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          name="title"
          placeholder="Title"
          className="w-full border rounded px-3 py-2"
          value={form.title}
          onChange={handleChange}
          required
        />
        <textarea
          name="description"
          placeholder="Description"
          className="w-full border rounded px-3 py-2"
          rows={4}
          value={form.description}
          onChange={handleChange}
          required
        ></textarea>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            name="price"
            placeholder="Price"
            className="w-full border rounded px-3 py-2"
            value={form.price}
            onChange={handleChange}
            required
          />
          <input
            type="number"
            name="bedrooms"
            placeholder="Bedrooms"
            className="w-full border rounded px-3 py-2"
            value={form.bedrooms}
            onChange={handleChange}
            required
          />
          <input
            type="number"
            name="bathrooms"
            placeholder="Bathrooms"
            className="w-full border rounded px-3 py-2"
            value={form.bathrooms}
            onChange={handleChange}
            required
          />
        </div>
        <input
          type="text"
          name="address"
          placeholder="Street address"
          className="w-full border rounded px-3 py-2"
          value={form.address}
          onChange={handleChange}
          required
        />
        <div className="grid grid-cols-3 gap-4">
          <input
            type="text"
            name="city"
            placeholder="City"
            className="w-full border rounded px-3 py-2"
            value={form.city}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="state"
            placeholder="State"
            className="w-full border rounded px-3 py-2"
            value={form.state}
            onChange={handleChange}
            required
          />
          <input
            type="text"
            name="country"
            placeholder="Country"
            className="w-full border rounded px-3 py-2"
            value={form.country}
            onChange={handleChange}
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="number"
            name="lat"
            placeholder="Latitude"
            className="w-full border rounded px-3 py-2"
            value={form.lat}
            onChange={handleChange}
            required
          />
          <input
            type="number"
            name="lng"
            placeholder="Longitude"
            className="w-full border rounded px-3 py-2"
            value={form.lng}
            onChange={handleChange}
            required
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="date"
            name="startDate"
            className="w-full border rounded px-3 py-2"
            value={form.startDate}
            onChange={handleChange}
            required
          />
          <input
            type="date"
            name="endDate"
            className="w-full border rounded px-3 py-2"
            value={form.endDate}
            onChange={handleChange}
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="bg-primary text-white px-6 py-3 rounded shadow hover:bg-primary/90 disabled:opacity-50"
        >
          {loading ? 'Creating...' : 'Create Listing'}
        </button>
      </form>
    </div>
  );
}
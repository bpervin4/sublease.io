import Link from 'next/link';
import { SearchBar } from '@/components/SearchBar';

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl px-4 py-16 flex flex-col items-center text-center space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl md:text-5xl font-bold">Find your next sublet or relet</h1>
        <p className="text-lg text-gray-600">Search by city, neighborhood or school and discover available homes with flexible terms.</p>
      </div>
      <div className="w-full max-w-xl">
        <SearchBar />
      </div>
      <div>
        <Link href="/list" className="inline-block rounded-md bg-primary px-6 py-3 text-white font-medium shadow hover:bg-primary/90 transition">List your space</Link>
      </div>
    </main>
  );
}
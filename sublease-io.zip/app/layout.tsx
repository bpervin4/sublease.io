import '@/app/globals.css';
import { Inter } from 'next/font/google';
import type { ReactNode } from 'react';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: {
    default: 'sublease.io – Find your next sublet or relet',
    template: '%s – sublease.io'
  },
  description: 'A modern marketplace for subleases and reletting. Search by location, filter by amenities, and list your space with ease.',
  twitter: {
    card: 'summary_large_image'
  }
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={inter.className}>
      <body>
        {/* Global header could go here */}
        {children}
      </body>
    </html>
  );
}
import { Suspense } from 'react';
import SearchResults from '@/components/SearchResults';

interface Props {
  searchParams: { [key: string]: string | string[] | undefined };
}

async function fetchListings(searchParams: Props['searchParams']) {
  const url = new URL(`${process.env.NEXTAUTH_URL ?? ''}/api/listings`);
  Object.entries(searchParams).forEach(([k, v]) => {
    if (v) url.searchParams.set(k, Array.isArray(v) ? v.join(',') : v);
  });
  const res = await fetch(url.toString(), { cache: 'no-store' });
  if (!res.ok) return [];
  const json = await res.json();
  return json.data;
}

export default async function SearchPage({ searchParams }: Props) {
  const listings = await fetchListings(searchParams);
  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <h1 className="text-2xl font-bold mb-4">Search Results</h1>
      <Suspense fallback={<p>Loading...</p>}>
        <SearchResults initialListings={listings} searchParams={searchParams} />
      </Suspense>
    </div>
  );
}
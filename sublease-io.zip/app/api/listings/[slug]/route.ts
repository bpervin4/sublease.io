import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

interface Params {
  params: { slug: string };
}

/**
 * GET /api/listings/[slug]
 *
 * Returns a single listing with full details.
 */
export async function GET(_request: Request, { params }: Params) {
  const { slug } = params;
  const listing = await prisma.listing.findUnique({
    where: { slug },
    include: {
      photos: { orderBy: { order: 'asc' } },
      lister: { select: { id: true, name: true, image: true } }
    }
  });
  if (!listing) {
    return NextResponse.json({ error: 'Not found' }, { status: 404 });
  }
  return NextResponse.json({ data: listing });
}
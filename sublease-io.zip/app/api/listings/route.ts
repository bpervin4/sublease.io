import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { SearchFilters } from '@/lib/types';
import slugify from 'slugify';

// Utility to parse numeric query parameters
function toNumber(value: string | null): number | undefined {
  if (!value) return undefined;
  const n = Number(value);
  return isNaN(n) ? undefined : n;
}

/**
 * GET /api/listings
 *
 * Supports query parameters:
 * - bbox: comma-separated bounding box [minLng,minLat,maxLng,maxLat]
 * - q: free-text search
 * - minPrice, maxPrice
 * - beds, baths
 * - homeType, leaseType
 * - amenities (comma-separated)
 * - view
 * - sort (priceAsc, priceDesc, newest)
 */
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const bbox = searchParams.get('bbox');
  const q = searchParams.get('q') ?? undefined;
  const minPrice = toNumber(searchParams.get('minPrice'));
  const maxPrice = toNumber(searchParams.get('maxPrice'));
  const beds = toNumber(searchParams.get('beds'));
  const baths = toNumber(searchParams.get('baths'));
  const homeType = searchParams.get('homeType') ?? undefined;
  const leaseType = searchParams.get('leaseType') ?? undefined;
  const amenities = searchParams.get('amenities')?.split(',').filter(Boolean);
  const view = searchParams.get('view') ?? undefined;
  const sort = searchParams.get('sort') ?? undefined;
  const page = toNumber(searchParams.get('page')) ?? 1;
  const perPage = toNumber(searchParams.get('perPage')) ?? 25;

  // Build Prisma where filter
  const where: any = {
    status: 'APPROVED'
  };
  if (minPrice) where.price = { gte: minPrice };
  if (maxPrice) where.price = { ...(where.price || {}), lte: maxPrice };
  if (beds) where.bedrooms = { gte: beds };
  if (baths) where.bathrooms = { gte: baths };
  if (homeType) where.homeType = homeType.toUpperCase();
  if (leaseType) where.leaseType = leaseType.toUpperCase();
  if (view) where.view = view;
  if (amenities && amenities.length > 0) {
    where.amenities = { hasSome: amenities };
  }
  if (q) {
    // Perform a simple case-insensitive search on title and description
    where.OR = [
      { title: { contains: q, mode: 'insensitive' } },
      { description: { contains: q, mode: 'insensitive' } },
      { city: { contains: q, mode: 'insensitive' } },
      { state: { contains: q, mode: 'insensitive' } }
    ];
  }
  if (bbox) {
    const parts = bbox.split(',').map((s) => parseFloat(s));
    if (parts.length === 4 && parts.every((n) => !isNaN(n))) {
      const [minLng, minLat, maxLng, maxLat] = parts;
      where.lat = { gte: minLat, lte: maxLat };
      where.lng = { gte: minLng, lte: maxLng };
    }
  }
  // Determine sort order
  let orderBy: any = { createdAt: 'desc' };
  if (sort === 'priceAsc') orderBy = { price: 'asc' };
  if (sort === 'priceDesc') orderBy = { price: 'desc' };
  if (sort === 'newest') orderBy = { createdAt: 'desc' };

  const listings = await prisma.listing.findMany({
    where,
    orderBy,
    skip: (page - 1) * perPage,
    take: perPage,
    select: {
      id: true,
      slug: true,
      title: true,
      city: true,
      state: true,
      price: true,
      bedrooms: true,
      bathrooms: true,
      lat: true,
      lng: true,
      photos: {
        orderBy: { order: 'asc' },
        take: 1,
        select: { url: true }
      }
    }
  });

  const results = listings.map((l) => ({
    id: l.id,
    slug: l.slug,
    title: l.title,
    city: l.city,
    state: l.state,
    price: l.price,
    bedrooms: Number(l.bedrooms),
    bathrooms: Number(l.bathrooms),
    lat: Number(l.lat),
    lng: Number(l.lng),
    imageUrl: l.photos[0]?.url || '/placeholder_light_gray_block.png'
  }));
  return NextResponse.json({ data: results, page, perPage });
}

/**
 * POST /api/listings
 *
 * Creates a new listing. Requires authentication; expected body to include all required
 * fields defined in the Prisma model. This is a simplified implementation and does not
 * handle image uploads or moderation.
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    // TODO: integrate authentication, validate input with zod, handle image uploads
    const {
      title,
      description,
      price,
      deposit,
      bedrooms,
      bathrooms,
      homeType,
      leaseType,
      lat,
      lng,
      address,
      city,
      state,
      country,
      postalCode,
      startDate,
      endDate,
      amenities,
      furnished,
      utilitiesIncluded,
      petsAllowed,
      parking,
      laundry,
      ac,
      elevator,
      gym,
      pool,
      view,
      accessibility,
      roommateCount,
      photos
    } = body;
    const slugBase = slugify(`${title}-${city}-${state}`, { lower: true, strict: true });
    // ensure slug uniqueness by appending random id
    const slug = `${slugBase}-${Math.random().toString(36).substring(2, 7)}`;
    const listing = await prisma.listing.create({
      data: {
        slug,
        title,
        description,
        price,
        deposit,
        bedrooms,
        bathrooms,
        homeType,
        leaseType,
        lat,
        lng,
        address,
        city,
        state,
        country,
        postalCode,
        startDate: new Date(startDate),
        endDate: endDate ? new Date(endDate) : null,
        amenities,
        furnished,
        utilitiesIncluded,
        petsAllowed,
        parking,
        laundry,
        ac,
        elevator,
        gym,
        pool,
        view,
        accessibility,
        roommateCount,
        photos: {
          createMany: {
            data: (photos || []).map((p: any, idx: number) => ({ url: p.url, alt: p.alt, order: idx }))
          }
        },
        lister: {
          connect: { id: body.listerId }
        },
        status: 'PENDING'
      },
      include: {
        photos: true
      }
    });
    return NextResponse.json({ data: listing }, { status: 201 });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: 'Failed to create listing' }, { status: 500 });
  }
}
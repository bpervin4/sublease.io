import NextAuth from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';

// This is a very basic NextAuth configuration. In a real application you
// should integrate OAuth providers (Google, Apple) and email magic links.

export const authOptions = {
  providers: [
    CredentialsProvider({
      name: 'Demo Credentials',
      credentials: {
        email: { label: 'Email', type: 'text', placeholder: 'demo@example.com' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        // TODO: look up user in database; for now accept any non-empty email/password
        if (credentials?.email && credentials?.password) {
          return { id: credentials.email, email: credentials.email } as any;
        }
        return null;
      }
    })
  ],
  session: {
    strategy: 'jwt'
  },
  callbacks: {
    async session({ session, token }: any) {
      session.user = { id: token.sub, email: token.email };
      return session;
    }
  }
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
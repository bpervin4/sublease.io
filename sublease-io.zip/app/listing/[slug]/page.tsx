import type { ListingDetail } from '@/lib/types';
import Image from 'next/image';
import dynamic from 'next/dynamic';
import { notFound } from 'next/navigation';

const MapView = dynamic(() => import('@/components/MapView').then((mod) => mod.MapView), { ssr: false });

interface Props {
  params: { slug: string };
}

async function fetchListing(slug: string): Promise<ListingDetail | null> {
  const res = await fetch(`${process.env.NEXTAUTH_URL ?? ''}/api/listings/${slug}`, { cache: 'no-store' });
  if (!res.ok) return null;
  const json = await res.json();
  return json.data;
}

export default async function ListingDetailPage({ params }: Props) {
  const listing = await fetchListing(params.slug);
  if (!listing) return notFound();
  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Gallery */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {listing.photos.map((photo, idx) => (
          <div key={idx} className="relative aspect-video bg-gray-200 rounded-lg overflow-hidden">
            <Image src={photo.url} alt={photo.alt ?? listing.title} fill className="object-cover" />
          </div>
        ))}
      </div>
      <h1 className="text-3xl font-bold">{listing.title}</h1>
      <div className="flex flex-wrap gap-4 text-gray-700 text-sm">
        <span>{listing.city}, {listing.state}</span>
        <span>{listing.bedrooms} bd</span>
        <span>{listing.bathrooms} ba</span>
        <span>{listing.sqft ? `${listing.sqft} sqft` : null}</span>
      </div>
      <div className="text-2xl font-semibold">${listing.price.toLocaleString()}</div>
      <p className="whitespace-pre-line text-gray-700">{listing.description}</p>
      {/* Amenities */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Amenities & Features</h2>
        <ul className="grid grid-cols-2 sm:grid-cols-3 gap-2 list-disc list-inside text-gray-700">
          {listing.amenities.map((a, idx) => <li key={idx}>{a}</li>)}
          {listing.furnished && <li>Furnished</li>}
          {listing.utilitiesIncluded && <li>Utilities Included</li>}
          {listing.petsAllowed && <li>Pets Allowed</li>}
          {listing.parking && <li>Parking</li>}
          {listing.laundry && <li>Laundry</li>}
          {listing.ac && <li>Air Conditioning</li>}
          {listing.elevator && <li>Elevator</li>}
          {listing.gym && <li>Gym</li>}
          {listing.pool && <li>Pool</li>}
          {listing.view && <li>View: {listing.view}</li>}
          {listing.accessibility && <li>Accessibility: {listing.accessibility}</li>}
        </ul>
      </div>
      {/* Availability */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Availability</h2>
        <p>Start: {new Date(listing.startDate).toLocaleDateString()}</p>
        {listing.endDate && <p>End: {new Date(listing.endDate).toLocaleDateString()}</p>}
      </div>
      {/* Map */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Location</h2>
        <div className="h-72 w-full rounded-md overflow-hidden">
          <MapView listings={[listing]} initialCenter={[listing.lng, listing.lat]} />
        </div>
      </div>
      {/* Contact */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Contact</h2>
        <p>To inquire about this listing, please sign in and send a message.</p>
        {/* TODO: implement messaging form */}
      </div>
    </div>
  );
}
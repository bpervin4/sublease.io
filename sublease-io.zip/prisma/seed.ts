import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  // Create a demo user to own the listings
  const user = await prisma.user.upsert({
    where: { email: 'demo@sublease.io' },
    update: {},
    create: {
      email: 'demo@sublease.io',
      name: 'Demo Lister'
    }
  });
  // Sample listings across US cities
  const listings = [
    {
      title: 'Sunny 2BR near Downtown Austin',
      description: 'Spacious two bedroom apartment with modern amenities within walking distance to downtown Austin.',
      price: 2000,
      bedrooms: 2,
      bathrooms: 2,
      homeType: 'APARTMENT' as const,
      leaseType: 'SUBLET' as const,
      address: '123 Main St',
      city: 'Austin',
      state: 'TX',
      country: 'USA',
      postalCode: '78701',
      lat: 30.2682,
      lng: -97.7428,
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 6)),
      amenities: ['Gym', 'Pool'],
      photos: [{ url: 'https://images.unsplash.com/photo-1560448204-e42f0fe7828a?auto=format&fit=crop&w=800&q=80' }]
    },
    {
      title: 'Cozy Room in Brooklyn Brownstone',
      description: 'Private room in a charming brownstone with shared kitchen and backyard.',
      price: 1200,
      bedrooms: 1,
      bathrooms: 1,
      homeType: 'ROOM' as const,
      leaseType: 'SUBLET' as const,
      address: '456 Park Pl',
      city: 'Brooklyn',
      state: 'NY',
      country: 'USA',
      postalCode: '11238',
      lat: 40.6806,
      lng: -73.9556,
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 3)),
      amenities: ['Laundry', 'Garden'],
      photos: [{ url: 'https://images.unsplash.com/photo-1572120360610-d971b9b67a3f?auto=format&fit=crop&w=800&q=80' }]
    },
    {
      title: 'Modern Studio in San Francisco',
      description: 'Sleek studio with panoramic city views and shared rooftop deck.',
      price: 2500,
      bedrooms: 0,
      bathrooms: 1,
      homeType: 'APARTMENT' as const,
      leaseType: 'RELET' as const,
      address: '789 Market St',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      postalCode: '94103',
      lat: 37.7749,
      lng: -122.4194,
      startDate: new Date(),
      endDate: new Date(new Date().setMonth(new Date().getMonth() + 9)),
      amenities: ['Gym', 'Elevator'],
      photos: [{ url: 'https://images.unsplash.com/photo-1559599101-44a3cafcac72?auto=format&fit=crop&w=800&q=80' }]
    },
    {
      title: 'Furnished 1BR near UCLA',
      description: 'Fully furnished one bedroom apartment walking distance to campus.',
      price: 1800,
      bedrooms: 1,
      bathrooms: 1,
      homeType: 'APARTMENT' as const,
      leaseType: 'SUBLET' as const,
      address: '321 Westwood Blvd',
      city: 'Los Angeles',
      state: 'CA',
      country: 'USA',
      postalCode: '90024',
      lat: 34.0689,
      lng: -118.4452,
      startDate: new Date(),
      endDate: null,
      amenities: ['Furnished', 'AC', 'Parking'],
      photos: [{ url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=800&q=80' }]
    },
    // additional sample entries...
  ];
  for (const data of listings) {
    const slugBase = `${data.title}-${data.city}-${data.state}`
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '');
    const slug = `${slugBase}-${Math.random().toString(36).substring(2, 7)}`;
    await prisma.listing.create({
      data: {
        slug,
        title: data.title,
        description: data.description,
        price: data.price,
        bedrooms: data.bedrooms,
        bathrooms: data.bathrooms,
        homeType: data.homeType,
        leaseType: data.leaseType,
        address: data.address,
        city: data.city,
        state: data.state,
        country: data.country,
        postalCode: data.postalCode,
        lat: data.lat,
        lng: data.lng,
        startDate: data.startDate,
        endDate: data.endDate,
        amenities: data.amenities,
        furnished: data.amenities.includes('Furnished'),
        utilitiesIncluded: false,
        petsAllowed: false,
        parking: data.amenities.includes('Parking'),
        laundry: data.amenities.includes('Laundry'),
        ac: data.amenities.includes('AC'),
        elevator: data.amenities.includes('Elevator'),
        gym: data.amenities.includes('Gym'),
        pool: data.amenities.includes('Pool'),
        photos: {
          createMany: {
            data: data.photos.map((p, idx) => ({ url: p.url, order: idx }))
          }
        },
        lister: { connect: { id: user.id } },
        status: 'APPROVED'
      }
    });
  }
  console.log('Database seeded.');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
/**
 * Shared TypeScript types used across the client and server.
 */

// Summary of a listing returned by the listings API for search result displays.
export interface ListingSummary {
  id: string;
  slug: string;
  title: string;
  city: string;
  state: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  lat: number;
  lng: number;
  imageUrl: string;
}

// Full listing representation used in detail pages.
export interface ListingDetail extends ListingSummary {
  description: string;
  deposit?: number;
  homeType: string;
  leaseType: string;
  sqft?: number;
  address: string;
  postalCode?: string;
  startDate: string; // ISO date
  endDate?: string; // ISO date
  amenities: string[];
  furnished: boolean;
  utilitiesIncluded: boolean;
  petsAllowed: boolean;
  parking: boolean;
  laundry: boolean;
  ac: boolean;
  elevator: boolean;
  gym: boolean;
  pool: boolean;
  view?: string;
  accessibility?: string;
  roommateCount?: number;
  photos: { url: string; alt?: string }[];
  lister: {
    id: string;
    name?: string;
    image?: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface SearchFilters {
  q?: string;
  bbox?: string;
  minPrice?: number;
  maxPrice?: number;
  beds?: number;
  baths?: number;
  homeType?: string;
  leaseType?: string;
  amenities?: string[];
  view?: string;
  sort?: string;
  page?: number;
  perPage?: number;
}
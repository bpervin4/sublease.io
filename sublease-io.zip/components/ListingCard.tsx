import Image from 'next/image';
import Link from 'next/link';

export interface ListingCardProps {
  slug: string;
  title: string;
  city: string;
  state: string;
  price: number;
  bedrooms: number;
  bathrooms: number;
  imageUrl: string;
}

/**
 * ListingCard renders a brief summary of a listing for use in search results and dashboards.
 */
export function ListingCard({ slug, title, city, state, price, bedrooms, bathrooms, imageUrl }: ListingCardProps) {
  return (
    <Link
      id={`listing-${slug}`}
      href={`/listing/${slug}`}
      className="block overflow-hidden rounded-lg shadow bg-white hover:shadow-lg transition"
    >
      <div className="relative h-40 w-full">
        {/* Cover image */}
        <Image src={imageUrl} alt={title} fill className="object-cover" sizes="300px" />
      </div>
      <div className="p-4 space-y-1">
        <h3 className="font-semibold text-lg truncate">{title}</h3>
        <p className="text-sm text-gray-500 truncate">{city}, {state}</p>
        <div className="flex justify-between items-center text-sm text-gray-700">
          <span>${price.toLocaleString()}</span>
          <span>{bedrooms}bd · {bathrooms}ba</span>
        </div>
      </div>
    </Link>
  );
}
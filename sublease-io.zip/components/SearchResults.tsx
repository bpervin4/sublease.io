"use client";

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ListingSummary, SearchFilters } from '@/lib/types';
import { ListingCard } from '@/components/ListingCard';
import { MapView } from '@/components/MapView';

interface Props {
  initialListings: ListingSummary[];
  searchParams: { [key: string]: string | string[] | undefined };
}

export default function SearchResults({ initialListings, searchParams }: Props) {
  const [listings, setListings] = useState<ListingSummary[]>(initialListings);
  const router = useRouter();
  const params = useSearchParams();

  // handle updating URL on filter changes (e.g., from filter bar)
  function updateSearchParams(newParams: Record<string, string | undefined>) {
    const url = new URL(window.location.href);
    Object.entries(newParams).forEach(([key, value]) => {
      if (value === undefined || value === '') {
        url.searchParams.delete(key);
      } else {
        url.searchParams.set(key, value);
      }
    });
    router.push(url.pathname + '?' + url.searchParams.toString());
  }

  // fetch listings when bounds or query params change
  async function fetchListingsWithParams(extra: Partial<SearchFilters> = {}) {
    const url = new URL('/api/listings', window.location.origin);
    // copy existing params
    params.forEach((value, key) => url.searchParams.set(key, value));
    Object.entries(extra).forEach(([key, value]) => {
      if (value !== undefined && value !== '') url.searchParams.set(key, String(value));
    });
    const res = await fetch(url.toString());
    if (res.ok) {
      const json = await res.json();
      setListings(json.data);
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
      {/* List */}
      <div className="lg:col-span-2 space-y-4 max-h-[80vh] overflow-y-auto">
        {listings.map((listing) => (
          <ListingCard key={listing.id} {...listing} />
        ))}
        {listings.length === 0 && <p>No listings found.</p>}
      </div>
      {/* Map */}
      <div className="lg:col-span-3 h-[80vh]">
        <MapView
          listings={listings}
          onBoundsChange={(bounds) => {
            const bbox = [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()].join(',');
            updateSearchParams({ bbox });
            fetchListingsWithParams({ bbox });
          }}
          onSelect={(listing) => {
            // scroll to listing in list
            const el = document.getElementById(`listing-${listing.id}`);
            el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }}
        />
      </div>
    </div>
  );
}
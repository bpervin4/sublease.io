"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';

/**
 * SearchBar allows users to input a location (city, neighborhood, school, zip).
 * On submit it navigates to the search page with the query as a parameter.
 */
export function SearchBar() {
  const [value, setValue] = useState('');
  const router = useRouter();

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const q = value.trim();
    if (q.length === 0) return;
    router.push(`/search?q=${encodeURIComponent(q)}`);
  }

  return (
    <form onSubmit={handleSubmit} className="flex rounded-md overflow-hidden shadow-md bg-white">
      <input
        type="text"
        className="flex-1 px-4 py-3 focus:outline-none"
        placeholder="Enter city, neighborhood or school..."
        value={value}
        onChange={(e) => setValue(e.target.value)}
      />
      <button type="submit" className="px-5 bg-primary text-white font-medium hover:bg-primary/90">
        Search
      </button>
    </form>
  );
}
"use client";

import { useEffect, useRef } from 'react';
import mapboxgl, { Map as MapboxMap } from 'mapbox-gl';
import type { ListingSummary } from '@/lib/types';

mapboxgl.accessToken = process.env.NEXT_PUBLIC_MAPBOX_TOKEN || process.env.MAPBOX_TOKEN || '';

export interface MapViewProps {
  listings: ListingSummary[];
  initialCenter?: [number, number];
  onBoundsChange?: (bounds: mapboxgl.LngLatBounds) => void;
  onSelect?: (listing: ListingSummary) => void;
}

/**
 * MapView renders an interactive Mapbox map with markers for each listing.
 * It is client-side only and will gracefully degrade when no token is provided.
 */
export function MapView({ listings, initialCenter = [-98.5795, 39.8283], onBoundsChange, onSelect }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstance = useRef<MapboxMap | null>(null);

  useEffect(() => {
    if (!mapRef.current || mapInstance.current) return;
    if (!mapboxgl.accessToken) return;
    const map = new mapboxgl.Map({
      container: mapRef.current,
      style: 'mapbox://styles/mapbox/streets-v11',
      center: initialCenter,
      zoom: 4
    });
    mapInstance.current = map;
    map.on('moveend', () => {
      if (onBoundsChange) onBoundsChange(map.getBounds());
    });
    return () => map.remove();
  }, [initialCenter, onBoundsChange]);

  // update markers whenever listings change
  useEffect(() => {
    const map = mapInstance.current;
    if (!map) return;
    // remove existing markers
    (map as any)._markers?.forEach((m: mapboxgl.Marker) => m.remove());
    (map as any)._markers = [];
    listings.forEach((listing) => {
      const el = document.createElement('div');
      el.className = 'w-3 h-3 bg-primary rounded-full border border-white cursor-pointer';
      const marker = new mapboxgl.Marker(el)
        .setLngLat([listing.lng, listing.lat])
        .addTo(map);
      (map as any)._markers.push(marker);
      if (onSelect) {
        el.addEventListener('click', () => onSelect(listing));
      }
    });
  }, [listings, onSelect]);

  return <div ref={mapRef} className="h-full w-full" />;
}